export const environment = {
  production: true,
  apiUrl: 'https://backend.proueducation.com/admin/api/',
  imageUrl: 'https://backend.proueducation.com/assets/upload/courses/',
  profileImage: 'https://backend.proueducation.com/assets/upload/users/',
  rzp_key_id: 'rzp_live_QDqz6GSpzE9Uzb'
};
